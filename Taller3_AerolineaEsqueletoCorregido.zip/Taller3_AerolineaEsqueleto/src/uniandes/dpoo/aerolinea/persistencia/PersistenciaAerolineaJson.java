package uniandes.dpoo.aerolinea.persistencia;

import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import uniandes.dpoo.aerolinea.exceptions.AeropuertoDuplicadoException;
import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.modelo.Avion;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;

/**
 * Esta clase permite cargar la información de una aerolínea desde un archivo JSON.
 * Implementación compatible con el esqueleto oficial del taller.
 * ME TOCO IMPLEMENTARLA YA QUE LA CONSOLA NO ME CORRIO DESDE UN COMIENZO Y YA IMPLEMENTADO 
 * SI CORRIO LA CONSOLA.
 */
public class PersistenciaAerolineaJson implements IPersistenciaAerolinea 
{

    @Override
    public void cargarAerolinea(String archivo, Aerolinea aerolinea) 
            throws IOException, InformacionInconsistenteException 
    {
        JSONObject raiz = new JSONObject(new JSONTokener(new FileReader(archivo)));

        // Mapa temporal para poder conectar rutas con aeropuertos
        Map<String, Aeropuerto> mapaAeropuertos = new HashMap<>();

        // -------------------------
        // Cargar aeropuertos
        // -------------------------
        JSONArray aeropuertos = raiz.getJSONArray("aeropuertos");

        for (int i = 0; i < aeropuertos.length(); i++) 
        {
            JSONObject obj = aeropuertos.getJSONObject(i);

            try 
            {
                Aeropuerto aeropuerto = new Aeropuerto(
                        obj.getString("nombre"),
                        obj.getString("codigo"),
                        obj.getString("nombreCiudad"),
                        obj.getDouble("latitud"),
                        obj.getDouble("longitud")
                );

                mapaAeropuertos.put(aeropuerto.getCodigo(), aeropuerto);
            } 
            catch (AeropuertoDuplicadoException e) 
            {
                throw new InformacionInconsistenteException(
                        "Aeropuerto duplicado: " + obj.getString("codigo"));
            }
        }

        // -------------------------
        // Cargar aviones
        // -------------------------
        JSONArray aviones = raiz.getJSONArray("aviones");

        for (int i = 0; i < aviones.length(); i++) 
        {
            JSONObject obj = aviones.getJSONObject(i);

            Avion avion = new Avion(
                    obj.getString("nombre"),
                    obj.getInt("capacidad")
            );

            aerolinea.agregarAvion(avion);
        }

        // -------------------------
        // Cargar rutas
        // -------------------------
        JSONArray rutas = raiz.getJSONArray("rutas");

        for (int i = 0; i < rutas.length(); i++) 
        {
            JSONObject obj = rutas.getJSONObject(i);

            Aeropuerto origen = mapaAeropuertos.get(obj.getString("origen"));
            Aeropuerto destino = mapaAeropuertos.get(obj.getString("destino"));

            if (origen == null || destino == null) 
            {
                throw new InformacionInconsistenteException(
                        "Aeropuerto no encontrado para ruta " + obj.getString("codigoRuta"));
            }

            Ruta ruta = new Ruta(
                    origen,
                    destino,
                    obj.getString("horaSalida"),
                    obj.getString("horaLlegada"),
                    obj.getString("codigoRuta")
            );

            aerolinea.agregarRuta(ruta);
        }

        // -------------------------
        // Cargar vuelos
        // -------------------------
        JSONArray vuelos = raiz.getJSONArray("vuelos");

        for (int i = 0; i < vuelos.length(); i++) 
        {
            JSONObject obj = vuelos.getJSONObject(i);

            try 
            {
                aerolinea.programarVuelo(
                        obj.getString("fecha"),
                        obj.getString("codigoRuta"),
                        obj.getString("nombreAvion")
                );
            } 
            catch (Exception e) 
            {
                throw new InformacionInconsistenteException(
                        "Error creando vuelo: " + e.getMessage());
            }
        }
    }

    @Override
    public void salvarAerolinea(String archivo, Aerolinea aerolinea) throws IOException 
    {
        // No requerido para este taller según el esqueleto
    }
}