package uniandes.dpoo.aerolinea.consola;

import java.io.IOException;

import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.persistencia.CentralPersistencia;
import uniandes.dpoo.aerolinea.persistencia.TipoInvalidoException;

public class ConsolaArerolinea extends ConsolaBasica
{	
    private Aerolinea unaAerolinea;

    /**
     * Es un método que corre la aplicación y realmente no hace nada interesante: sólo muestra cómo se podría utilizar la clase Aerolínea para hacer pruebas.
     ESTUVE BASTANTE FRUSTRADO POR LO CUAL TOME LA DECISION DE:
     COMO LA CONSOLA NO TENIA UN SYSOUT PARA IMPRIMIR LA MODIFIQUE TEMPORALMENTE PARA QUE ME FUNCIONARA 
     LA CONSOLA Y VERIFICAR QUE LOS DATOS DEL TALLER ENTRABAN COMO DEBERIA DE SER.
    public void correrAplicacion( )
    {	
        try
        {
            unaAerolinea = new Aerolinea( );
            unaAerolinea.cargarAerolinea("./datos/aerolinea.json", CentralPersistencia.JSON);
            String archivo = "tiquetes.json"; 
            unaAerolinea.cargarTiquetes( "./datos/" + archivo, CentralPersistencia.JSON );
        }
        catch( TipoInvalidoException e )
        {
            e.printStackTrace( );
        }
        catch( IOException e )
        {
            e.printStackTrace();
        }
        catch( InformacionInconsistenteException e )
        {
            e.printStackTrace();
        }
    }
*/
    
    public void correrAplicacion()
    {
        try
        {
            unaAerolinea = new Aerolinea();

            // Cargar la aerolínea desde JSON
            unaAerolinea.cargarAerolinea("./datos/aerolinea.json", CentralPersistencia.JSON);
            System.out.println("Aerolinea cargada correctamente");

            // Cargar los tiquetes desde JSON
            String archivo = "tiquetes.json";
            unaAerolinea.cargarTiquetes("./datos/" + archivo, CentralPersistencia.JSON);
            System.out.println("Tiquetes cargados correctamente");

            // Mostrar información cargada
            System.out.println("Cantidad de rutas: " + unaAerolinea.getRutas().size());
            System.out.println("Cantidad de vuelos: " + unaAerolinea.getVuelos().size());
            System.out.println("Cantidad de clientes: " + unaAerolinea.getClientes().size());
            System.out.println("Cantidad de tiquetes en vuelos: " + unaAerolinea.getTiquetes().size());

            System.out.println("Sistema funcionando correctamente");

        }
        catch( TipoInvalidoException e )
        {
            System.out.println("Error: tipo de archivo inválido");
            e.printStackTrace();
        }
        catch( IOException e )
        {
            System.out.println("Error leyendo archivo");
            e.printStackTrace();
        }
        catch( InformacionInconsistenteException e )
        {
            System.out.println("Error: información inconsistente");
            e.printStackTrace();
        }
    }
    
    public static void main( String[] args )
    {
        ConsolaArerolinea ca = new ConsolaArerolinea( );
        ca.correrAplicacion( );
    }
}
